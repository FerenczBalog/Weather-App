console.log('Hello World')


// Változók

let name  = "John" // a / name = Jani / parancsal az előző parancs megváltoztatható
const lastname = "Cris" // a / lastname = Péter / parancs nem használható jelen esetben

name = "Jani"

console.log (name, lastname)

// Operátórók + - * / ** // % ++ --

// Adat típusok

// String = szövegek '' vagy "" között

// Számok = ha '' vagy "" közá rakjuk stringnek  számít, ezért símán kell lírni

szam = 2

// Boolean = True vagy Fals

// Undifined = meghatározatlan változó

// Null = nem meghatározatlan de nem ír le semmit

const semmi = null;

// Array = tartalmazhat bármilyen adatot, meghataroz egy eszkoz kollekciot
//ahhoz, hogy hozzaferjunk valamelyik elemhez indexeket hasznalunk 

const szinek = ["piros", "zold", "kek", 25, 'kakukk', null]
//indexek         0          1    2      3   4       5

console.log(szinek[0], 'piros'); //piros
console.log(szinek[4], 'kakukk'); //kakukk

// Objektumok *KEY VALUE-PAIR = KULCS-ERTEK PAROS pl: nev -> kulcs ferencz -> ertek. Tartalmazhat barmilyen adatot

const person = {
    'nev': 'ferencz',
    'kor': 25,
    'lakhely': 'Kolozsvar',
    'hallgato': {
        'egyetem':'Sapi',
        'iskolaev': '2014-2017'
    }
}

/* Elohivas
console.log (person.nev, PONTTAL)
console.log (person['nev'], szogletes haromszoggel)
*/

console.log (person.nev, 'pontos verzio')
console.log ( person['nev'], 'szogletes zarojeles verzio')

console.log (person.hallgato)

// Oszehasonlito opearatorok

/* EGYENLO ==  ===
== -> a stringet is szamba veszi mig a === csak a szamokat
pl.

1 == '1' -> true, csak az ;rt;ket figyeli, nem az adat tipusat is
1 ==='1' -> false

*/

/* NEM EGYENLO != !== */

1 != 2 // TRUE
1 != 1 // FALSE

1 !== '1'
1 !== 2

/* >  >=  <  <= */

// Logikai operátorok

// and = &&    Ha mindkét eredmény igaz akkor a végeredmény is igaz
//A //B //EREDMENY 

| 1 | 1 | true
| 0 | 1 | false
| 1 | 0 | false
| 0 | 0 | false


// or = ||    Ha egyikük igaz akkor a végeredmény igazi

| 1 | 1 | true
| 0 | 1 | true
| 1 | 0 | true
| 0 | 0 | false

// not = !      ELLENTÉTeT FEJEz KI 

| 1 | 1 | false
| 0 | 1 | false
| 1 | 0 | false
| 0 | 0 | true

// If, if else, switch

if(1>2) { // ha
    console.log("true");
} else {   // külömben
    console.log("false")
}

if(1>2) { // ha 
    console.log("true");
} else if (1<2){ //külömben
    console.log("1 < 2")
} else {  // ha egyik sem igaz a felsők közül
    console.log("false")
}

// switch
const number = 4;
switch(number) {
    case 3:
        console.log ("it's 3");
        break;
    case 5:
        console.log ("it's 5");
        break;
    case 4:
        console.log ("it's 4");
        break;
    default:
        console.log ("no data")
}


// LOOP = Végig visz egy kódott n-szer

/* for loop */

const mere = "alma";
//   "a l m a"
//   0 1 2 3

for(let i = 0; i < mere.length; i++) {
    console.log(mere[i], i);
}

/* while */

/*  infinite loop
while(true) {
    console.log("a")
}*/

let i = 0;
while(i < 100) {
    console.log(i);
    i++

    if(i = 50){
        console.log("Loop stoped")
    break;
    }
}

// for loop objektumnak

const person2 = {
    'nev': 'ferencz',
    'kor': 25,
    'lakhely': 'Kolozsvar',
}

for(let key in person2) {
    console.log (person2[key]);
}

// Funkciók

console.log("Functions")

function calculeaza(a, b) {
    console.log(a + b)
}

calculeaza(5, 1)

//

const calculeaz = (a, b) => {
    console.log(a + b)
}

calculeaz(5, 2)

//

const calcul = (a, b) => {
    return (a + b);
}

calculeaz(5, 5)

// DOM = Document object model

const paragrafe = Array.from (document.querySelectorAll("p"));

paragrafe.forEach(function (p, i) { 
    p.innerText = "Lorem Ipsum " + i;
});

setTimeout( () => {
    paragrafe.forEach((p,i) => {
        p.innerText="Lorem Ipsum";
        p.classList.add("blue");
    });
    p.classList.add("blue");
}, 2000);
